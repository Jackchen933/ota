./objects/segger_rtt.o: ..\Middlewares\RTT\SEGGER_RTT.c \
  ..\Middlewares\RTT\SEGGER_RTT.h ..\Middlewares\RTT\SEGGER_RTT_Conf.h \
  D:\ProgramFile\MDK\Core\ARM\ARMCLANG\Bin\..\include\stdlib.h \
  D:\ProgramFile\MDK\Core\ARM\ARMCLANG\Bin\..\include\stdarg.h \
  D:\ProgramFile\MDK\Core\ARM\ARMCLANG\Bin\..\include\stdint.h \
  D:\ProgramFile\MDK\Core\ARM\ARMCLANG\Bin\..\include\string.h
