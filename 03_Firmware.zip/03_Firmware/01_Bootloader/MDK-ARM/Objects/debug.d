./objects/debug.o: ..\Tasks\Debug\Debug.c \
  ..\Middlewares\easylogger\inc\elog.h \
  ..\Middlewares\easylogger\inc\elog_cfg.h \
  D:\ProgramFile\MDK\Core\ARM\ARMCLANG\Bin\..\include\stdint.h \
  D:\ProgramFile\MDK\Core\ARM\ARMCLANG\Bin\..\include\stddef.h \
  D:\ProgramFile\MDK\Core\ARM\ARMCLANG\Bin\..\include\stdbool.h \
  ..\Tasks\Debug\Debug.h \
  D:\ProgramFile\MDK\Core\ARM\ARMCLANG\Bin\..\include\stdio.h
