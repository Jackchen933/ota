./objects/aes.o: ..\Middlewares\AES\Algorithms\src\aes.c \
  ..\Middlewares\AES\Algorithms\inc\aes.h \
  D:\ProgramFile\MDK\Core\ARM\ARMCLANG\Bin\..\include\string.h
