./objects/elog.o: ..\Middlewares\easylogger\src\elog.c \
  ..\Middlewares\easylogger\inc\elog.h \
  ..\Middlewares\easylogger\inc\elog_cfg.h \
  D:\ProgramFile\MDK\Core\ARM\ARMCLANG\Bin\..\include\stdint.h \
  D:\ProgramFile\MDK\Core\ARM\ARMCLANG\Bin\..\include\stddef.h \
  D:\ProgramFile\MDK\Core\ARM\ARMCLANG\Bin\..\include\stdbool.h \
  D:\ProgramFile\MDK\Core\ARM\ARMCLANG\Bin\..\include\string.h \
  D:\ProgramFile\MDK\Core\ARM\ARMCLANG\Bin\..\include\stdarg.h \
  D:\ProgramFile\MDK\Core\ARM\ARMCLANG\Bin\..\include\stdio.h
