./objects/elog_utils.o: ..\Middlewares\easylogger\src\elog_utils.c \
  ..\Middlewares\easylogger\inc\elog.h \
  ..\Middlewares\easylogger\inc\elog_cfg.h \
  D:\ProgramFile\MDK\Core\ARM\ARMCLANG\Bin\..\include\stdint.h \
  D:\ProgramFile\MDK\Core\ARM\ARMCLANG\Bin\..\include\stddef.h \
  D:\ProgramFile\MDK\Core\ARM\ARMCLANG\Bin\..\include\stdbool.h \
  D:\ProgramFile\MDK\Core\ARM\ARMCLANG\Bin\..\include\string.h
