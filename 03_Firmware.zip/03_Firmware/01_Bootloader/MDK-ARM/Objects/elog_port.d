./objects/elog_port.o: ..\Middlewares\easylogger\port\elog_port.c \
  ..\Middlewares\easylogger\inc\elog.h \
  ..\Middlewares\easylogger\inc\elog_cfg.h \
  D:\ProgramFile\MDK\Core\ARM\ARMCLANG\Bin\..\include\stdint.h \
  D:\ProgramFile\MDK\Core\ARM\ARMCLANG\Bin\..\include\stddef.h \
  D:\ProgramFile\MDK\Core\ARM\ARMCLANG\Bin\..\include\stdbool.h \
  ..\Middlewares\RTT\SEGGER_RTT.h ..\Middlewares\RTT\SEGGER_RTT_Conf.h \
  D:\ProgramFile\MDK\Core\ARM\ARMCLANG\Bin\..\include\stdlib.h \
  D:\ProgramFile\MDK\Core\ARM\ARMCLANG\Bin\..\include\stdarg.h
